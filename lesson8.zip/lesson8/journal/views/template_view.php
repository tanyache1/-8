<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<title>Главная</title>
	<link rel="stylesheet" type="text/css" href="views/styles.css">
</head>
<body>
	<?php include 'views/'.$content_view; ?>
</body>
</html>